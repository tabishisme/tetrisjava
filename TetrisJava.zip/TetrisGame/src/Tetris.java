import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

public class Tetris extends JFrame implements KeyListener {
    private final int WIDTH = 10;
    private final int HEIGHT = 20;
    private final int DELAY = 400;

    private Timer timer;
    private boolean[][] board;
    private ArrayList<Point> currentPiece;
    private int currentX, currentY;
    private Random random;
    private boolean gameOver;

    public Tetris() {
        setTitle("Tetris");
        setSize(300, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        board = new boolean[HEIGHT][WIDTH];
        currentPiece = new ArrayList<>();
        random = new Random();
        timer = new Timer(DELAY, new TimerListener());
        gameOver = false;

        addKeyListener(this);
        startGame();
    }

    private void startGame() {
        timer.start();
        spawnPiece();
    }

    private void spawnPiece() {
        currentX = WIDTH / 2;
        currentY = 0;
        currentPiece.clear();

        int pieceType = random.nextInt(7);
        switch (pieceType) {
            case 0: // I
                currentPiece.add(new Point(0, 0));
                currentPiece.add(new Point(0, 1));
                currentPiece.add(new Point(0, 2));
                currentPiece.add(new Point(0, 3));
                break;
            case 1: // J
                currentPiece.add(new Point(0, 0));
                currentPiece.add(new Point(1, 0));
                currentPiece.add(new Point(1, 1));
                currentPiece.add(new Point(1, 2));
                break;
            case 2: // L
                currentPiece.add(new Point(1, 0));
                currentPiece.add(new Point(1, 1));
                currentPiece.add(new Point(1, 2));
                currentPiece.add(new Point(0, 2));
                break;
            case 3: // O
                currentPiece.add(new Point(0, 0));
                currentPiece.add(new Point(0, 1));
                currentPiece.add(new Point(1, 0));
                currentPiece.add(new Point(1, 1));
                break;
            case 4: // S
                currentPiece.add(new Point(1, 0));
                currentPiece.add(new Point(0, 1));
                currentPiece.add(new Point(1, 1));
                currentPiece.add(new Point(0, 2));
                break;
            case 5: // T
                currentPiece.add(new Point(0, 0));
                currentPiece.add(new Point(1, 0));
                currentPiece.add(new Point(2, 0));
                currentPiece.add(new Point(1, 1));
                break;
            case 6: // Z
                currentPiece.add(new Point(0, 0));
                currentPiece.add(new Point(0, 1));
                currentPiece.add(new Point(1, 1));
                currentPiece.add(new Point(1, 2));
                break;
        }

        if (isColliding()) {
            gameOver = true;
            timer.stop();
        }
    }

    private boolean isColliding() {
        for (Point point : currentPiece) {
            int x = currentX + point.x;
            int y = currentY + point.y;
            if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT || board[y][x]) {
                return true;
            }
        }
        return false;
    }

    private void moveDown() {
        currentY++;
        if (isColliding()) {
            currentY--;
            placePiece();
            clearLines();
            spawnPiece();
        }
    }

    private void moveLeft() {
        currentX--;
        if (isColliding()) {
            currentX++;
        }
    }

    private void moveRight() {
        currentX++;
        if (isColliding()) {
            currentX--;
        }
    }

    private void rotatePiece() {
        ArrayList<Point> rotatedPiece = new ArrayList<>();
        for (Point point : currentPiece) {
            int x = point.y;
            int y = -point.x;
            rotatedPiece.add(new Point(x, y));
        }
        currentPiece = rotatedPiece;
        if (isColliding()) {
            currentPiece = new ArrayList<>(rotatedPiece); // Revert rotation
        }
    }

    private void placePiece() {
        for (Point point : currentPiece) {
            int x = currentX + point.x;
            int y = currentY + point.y;
            if (y >= 0) {
                board[y][x] = true;
            }
        }
    }

    private void clearLines() {
        for (int i = HEIGHT - 1; i >= 0; i--) {
            boolean lineFull = true;
            for (int j = 0; j < WIDTH; j++) {
                if (!board[i][j]) {
                    lineFull = false;
                    break;
                }
            }
            if (lineFull) {
                for (int k = i; k > 0; k--) {
                    System.arraycopy(board[k - 1], 0, board[k], 0, WIDTH);
                }
                i++; // Re-check the same line
            }
        }
    }

    private class TimerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            moveDown();
            repaint();
        }
    }

    private void drawPiece(Graphics g) {
        for (Point point : currentPiece) {
            int x = (currentX + point.x) * 30;
            int y = (currentY + point.y) * 30;
            g.setColor(Color.BLUE);
            g.fillRect(x, y, 30, 30);
            g.setColor(Color.BLACK);
            g.drawRect(x, y, 30, 30);
        }
    }

    private void drawBoard(Graphics g) {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                if (board[i][j]) {
                    g.setColor(Color.RED);
                    g.fillRect(j * 30, i * 30, 30, 30);
                    g.setColor(Color.BLACK);
                    g.drawRect(j * 30, i * 30, 30, 30);
                }
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        drawPiece(g);
        drawBoard(g);
        if (gameOver) {
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("Game Over", 70, getHeight() / 2);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        if (!gameOver) {
            if (keyCode == KeyEvent.VK_LEFT) {
                moveLeft();
            } else if (keyCode == KeyEvent.VK_RIGHT) {
                moveRight();
            } else if (keyCode == KeyEvent.VK_DOWN) {
                moveDown();
            } else if (keyCode == KeyEvent.VK_UP) {
                rotatePiece();
            }
            repaint();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Tetris tetris = new Tetris();
            tetris.setVisible(true);
        });
    }
}

